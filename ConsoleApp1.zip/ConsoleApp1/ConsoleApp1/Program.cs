﻿using System;

namespace ConsoleApp1
{
	using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Cryptography.X509Certificates;
    using System.Threading;
    using System.Transactions;

    public class Program
		{

		private const string QUIT = "3";

		public static void Main(string[] args)
			{



		Start:
			Console.WriteLine("Start elevator Testing!!");

			int floor; string floorInput; Elevator elevator;

			string elevatorInput = "";
			string E1, E2, E3;

			E1 = "7";
			E2 = "4";
			E3 = "-2";

			Console.WriteLine("Total Number of Elevator are 3------> E1,E2,E3");
			Console.WriteLine("Current Position of the Elevator are  E1----- is " + E1 + "th Floor and E2---- is " + E2 + "th floor E3 ----is" + E3 +"th Floor");
			Console.WriteLine("Please Enter the total number of floors in the building ?");

			floorInput = Console.ReadLine();

			Console.WriteLine("Please chooose the avaliable elevator E1/E2/E3");
			elevatorInput = Console.ReadLine();

			if(elevatorInput =="E1") 
            {
				Console.WriteLine(" chooosen elevator is E1 ");
				
			}
			else if (elevatorInput =="E2")
			{
				Console.WriteLine(" chooosen elevator is is E2 ");
			}

			else if (elevatorInput =="E3")
			{
				Console.WriteLine(" chooosen elevator is is E3 ");
			}
            else
            {
				Console.WriteLine(" Please chooose only avaliable elevator ");
				goto Start;
			}

			if (Int32.TryParse(floorInput, out floor))
					elevator = new Elevator(floor);
				else
				{
					Console.WriteLine("That' doesn't make sense...");
					Console.Beep();
					Thread.Sleep(2000);
					Console.Clear();
					goto Start;
				}
				string input = string.Empty;

				while (input != QUIT)
				{
					Console.WriteLine("Please press which floor you would like to go to");

					input = Console.ReadLine();
					if (Int32.TryParse(input, out floor))
						elevator.FloorPress(floor);
					else if (input == QUIT)
						Console.WriteLine("GoodBye!");
					else
						Console.WriteLine("You have pressed an incorrect floor, Please try again");




				// Feel free to change these inputs

				 int totalcount = 0;

				if (Int32.TryParse(floorInput, out floor))
                {
					totalcount = floor;

				}
				  int numberOfFloors = totalcount;
				  int numberOfElevators = 1;
			    int numberOfRequests = numberOfFloors * numberOfElevators;

				// Don't change anything below this line
				var pickupCount = 0;
				var stepCount = 0;
				var random = new Random();
				IElevatorControlSystem system = new ControlSystem(numberOfElevators);


				while (pickupCount < numberOfRequests)
				{
					var originatingFloor = random.Next(1, numberOfFloors + 1);
					var destinationFloor = random.Next(1, numberOfFloors + 1);
					if (originatingFloor != destinationFloor)
					{
						system.Pickup(originatingFloor, destinationFloor);
						pickupCount++;
					}
				}

				while (system.AnyOutstandingPickups())
				{
					system.Step();
					stepCount++;
				}

				Console.WriteLine("elevator riders to their requested destinations in {1} steps.", pickupCount, stepCount);
				Console.ReadLine();

			}
		}

		
		}


		public class Elevator
		{
			private bool[] floorReady;
			public int CurrentFloor = 1;
			private int topfloor;
			public ElevatorStatus Status = ElevatorStatus.STOPPED;

			public Elevator(int NumberOfFloors = 10)
			{
				floorReady = new bool[NumberOfFloors + 1];
				topfloor = NumberOfFloors;
			}

			private void Stop(int floor)
			{
				Status = ElevatorStatus.STOPPED;
				CurrentFloor = floor;
				floorReady[floor] = false;
				Console.WriteLine("Stopped at floor {0}", floor);
			}

			private void Descend(int floor)
			{
				for (int i = CurrentFloor; i >= 1; i--)
				{
					if (floorReady[i])
						Stop(floor);
					else
						continue;
				}

				Status = ElevatorStatus.STOPPED;
				Console.WriteLine("Waiting..");
			}

			private void Ascend(int floor)
			{
				for (int i = CurrentFloor; i <= topfloor; i++)
				{
					if (floorReady[i])
						Stop(floor);
					else
						continue;
				}

				Status = ElevatorStatus.STOPPED;
				Console.WriteLine("Waiting..");
			}

			void StayPut()
			{
				Console.WriteLine("That's our current floor");
			}

			public void FloorPress(int floor)
			{
				if (floor > topfloor)
				{
					Console.WriteLine("We only have {0} floors", topfloor);
					return;
				}

				floorReady[floor] = true;

				switch (Status)
				{

					case ElevatorStatus.DOWN:
						Descend(floor);
						break;

					case ElevatorStatus.STOPPED:
						if (CurrentFloor < floor)
							Ascend(floor);
						else if (CurrentFloor == floor)
							StayPut();
						else
							Descend(floor);
						break;

					case ElevatorStatus.UP:
						Ascend(floor);
						break;

					default:
						break;
				}


			}

			public enum ElevatorStatus
			{
				UP,
				STOPPED,
				DOWN
			}
		}

	public interface IElevatorControlSystem
	{
		ElevatorTest GetStatus(int elevatorId);
		void Update(int elevatorId, int floorNumber, int goalFloorNumber);
		void Pickup(int pickupFloor, int destinationFloor);
		void Step();
		bool AnyOutstandingPickups();
	}

	public class ControlSystem : IElevatorControlSystem
	{
		public List<ElevatorTest> Elevators { get; set; }
		public List<RiderTest> WaitingRiders { get; set; }

		public ControlSystem(int numberOfElevators)
		{
			Elevators = Enumerable.Range(0, numberOfElevators).Select(eid => new ElevatorTest(eid)).ToList();
			WaitingRiders = new List<RiderTest>();
		}


		public ElevatorTest GetStatus(int elevatorId)
		{
			return Elevators.First(e => e.Id == elevatorId);
		}

		public void Update(int elevatorId, int floorNumber, int goalFloorNumber)
		{
			UpdateElevator(elevatorId, e =>
			{
				e.CurrentFloor = floorNumber;
				e.DestinationFloor = goalFloorNumber;
			});
		}

		public void Pickup(int pickupFloor, int destinationFloor)
		{
			WaitingRiders.Add(new RiderTest(pickupFloor, destinationFloor));
		}

		private void UpdateElevator(int elevatorId, Action<ElevatorTest> update)
		{
			Elevators = Elevators.Select(e =>
			{
				if (e.Id == elevatorId) update(e);
				return e;
			}).ToList();
		}

		public void Step()
		{
			var busyElevatorIds = new List<int>();
			// unload elevators
			Elevators = Elevators.Select(e =>
			{
				var disembarkingRiders = e.Riders.Where(r => r.DestinationFloor == e.CurrentFloor).ToList();
				if (disembarkingRiders.Any())
				{
					busyElevatorIds.Add(e.Id);
					e.Riders = e.Riders.Where(r => r.DestinationFloor != e.CurrentFloor).ToList();
				}

				return e;
			}).ToList();

			// Embark passengers to available elevators
			WaitingRiders.GroupBy(r => new { r.OriginatingFloor, r.Direction }).ToList().ForEach(waitingFloor =>
			{
				var availableElevator =
					Elevators.FirstOrDefault(
						e =>
							e.CurrentFloor == waitingFloor.Key.OriginatingFloor &&
							(e.Direction == waitingFloor.Key.Direction || !e.Riders.Any()));
				if (availableElevator != null)
				{
					busyElevatorIds.Add(availableElevator.Id);
					var embarkingPassengers = waitingFloor.ToList();
					UpdateElevator(availableElevator.Id, e => e.Riders.AddRange(embarkingPassengers));
					WaitingRiders = WaitingRiders.Where(r => embarkingPassengers.All(er => er.Id != r.Id)).ToList();
				}
			});


			Elevators.ForEach(e =>
			{
				var isBusy = busyElevatorIds.Contains(e.Id);
				int destinationFloor;
				if (e.Riders.Any())
				{
					var closestDestinationFloor =
						e.Riders.OrderBy(r => Math.Abs(r.DestinationFloor - e.CurrentFloor))
							.First()
							.DestinationFloor;
					destinationFloor = closestDestinationFloor;
				}
				else if (e.DestinationFloor == e.CurrentFloor && WaitingRiders.Any())
				{
					// Lots of optimization could be done here, perhaps?
					destinationFloor = WaitingRiders.GroupBy(r => new { r.OriginatingFloor }).OrderBy(g => g.Count()).First().Key.OriginatingFloor;
				}
				else
				{
					destinationFloor = e.DestinationFloor;
				}

				var floorNumber = isBusy
					? e.CurrentFloor
					: e.CurrentFloor + (destinationFloor > e.CurrentFloor ? 1 : -1);

				Update(e.Id, floorNumber, destinationFloor);
			});
		}

		public bool AnyOutstandingPickups()
		{
			return WaitingRiders.Any();
		}
	}

	public class ElevatorTest
	{
		public ElevatorTest(int id)
		{
			Id = id;
			Riders = new List<RiderTest>();
		}

		public int Id { get; private set; }
		public int CurrentFloor { get; set; }
		public int DestinationFloor { get; set; }

		public Direction Direction
		{
			get
			{
				return CurrentFloor == 1
					? Direction.Up
					: DestinationFloor > CurrentFloor ? Direction.Up : Direction.Down;
			}
		}

		public List<RiderTest> Riders { get; set; }
	}

	public class RiderTest
	{
		public RiderTest(int originatingFloor, int destinationFloor)
		{
			OriginatingFloor = originatingFloor;
			DestinationFloor = destinationFloor;
			Id = Guid.NewGuid();
		}

		public Guid Id { get; private set; }
		public int OriginatingFloor { get; private set; }
		public int DestinationFloor { get; private set; }

		public Direction Direction
		{
			get { return OriginatingFloor < DestinationFloor ? Direction.Up : Direction.Down; }
		}
	}

	public enum Direction
	{
		Up = 1,
		Down = -1
	}



}
